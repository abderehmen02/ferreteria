export const appConfig = {
    appName : "FERRETERÍA BAZAR HOGAR" ,
    logo: "/logo.jpg" , 
    notFoundImg : "/notFoundImg.jpg"  ,
    routes :{
        home : "/" ,
        rebajas : "/Rebajas" , 
        LosMásVendidos : "/LosMásVendidos" , 
        DiseñoDeInteriores : "/DiseñoDeInteriores" , 
        ProductosPersonalizados : "/ProductosPersonalizados"
    }
}


